/* <div class="pb-3">
	<div class="p-2"><img class="me-2" src="placeholder-user.png" width="32" height="32">JJones20</div>
	<div class="ps-2 pb-2">This is me and my houseAAAAAAAAAAAAAAA AAAAAAAAAAA A AAAAAAAAA AAAAAA AAAAAAAAAA</div>
	<!-- <canvas width="400" height="300" class="w-100 bg-light bg-gradient"></canvas> -->
	<img class="w-100 h-auto border-top border-bottom" src="placeholder-drawing-1.jpg" width="400" height="300">
	<div class="row gx-0 ps-2">
		<div class="col-6 d-flex align-items-center">
			<i class="bi bi-pencil-fill pe-2"></i>
			<span class="pe-2">200</span>
			<i class="bi bi-chat-left-fill pe-2"></i>
			<span>200</span>
		</div>
		<div class="col-6 d-flex justify-content-end">
			<button class="btn btn-sm btn-white text-primary text-right">View replies <i class="bi bi-arrow-right"></i></button>
		</div>
	</div>
</div> */

class Drawing {
	constructor (image, user, description, drawingData, drawingResponses, textResponses) {
		this.image = image;
		this.user = user;
		this.description = description;
		this.drawingData = drawingData;
		this.drawingResponses = drawingResponses;
		this.textResponses = textResponses;


		this.root = document.createElement("div");
		this.root.className = "pb-3";

		this.userArea = document.createElement("div");
		this.userArea.className = "p-2";
		
		this.userImage = document.createElement("img");
		this.userImage.className = "me-2";
		this.userImage.src = this.image;

		this.descriptionText = document.createElement("div");
		this.descriptionText.className = "ps-2 pb-2";
		this.descriptionText.innerHTML = description;
		

		this.drawArea = document.createElement("img") // in the final version this will be a canvas that renders the drawing
		this.drawArea.className = "w-100 h-auto border-top border-bottom";
		this.drawArea.src = drawingData;
		
		this.postStatArea = document.createElement("div");
		this.postStatArea.className = "row gx-0 ps-2";
		this.postStatArea.innerHTML = `
		<div class="col-6 d-flex align-items-center">
			<i class="bi bi-pencil-fill pe-2"></i>
			<span class="pe-2">${drawingResponses}</span>
			<i class="bi bi-chat-left-fill pe-2"></i>
			<span>${textResponses}</span>
		</div>
		<div class="col-6 d-flex justify-content-end">
			<button class="btn btn-sm btn-white text-primary text-right">View replies <i class="bi bi-arrow-right"></i></button>
		</div>`;
		this.userArea.appendChild(this.userImage);
		this.userArea.innerHTML += this.user;
		this.root.appendChild(this.userArea);
		this.root.appendChild(this.descriptionText);
		this.root.appendChild(this.drawArea);
		this.root.appendChild(this.postStatArea);
	}
	Create (element) {
		element.appendChild (this.root);
		console.log('test');
	}
}


var drawings = [
	new Drawing ("placeholder-user.png", "Jimbo123", "This is me and my housee", "placeholder-drawing-1.jpg", 42, 9),
	new Drawing ("placeholder-user.png", "Kyl3", "My dog skippy", "placeholder-drawing-2.jpg", 10, 12),
	new Drawing ("placeholder-user.png", "Beachb0y", "I like the beach I drew the beahc", "placeholder-drawing-3.jpg", 2, 5)
]

for (var i =0; i < drawings.length; i++) {
	drawings[i].Create ($("#Drawings")[0]);
}